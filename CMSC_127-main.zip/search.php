<?php
	include 'connect.php'
?>
<html lang=en>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> HMMbois - School Library </title> 
	<link  rel="stylesheet" type="text/css" href="style.css" />

	<!-- Usage of Online Resources -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

	<!---- Header section ---->
	<section class="header">
		<div class="navbar">
				<div class = "logo">
					<img src="img/logo.png" width="125px">
				</div>
			<nav>
				<ul>
					<li><a href="#header">Home</a></li>
					<li><a href="#header">Search</a></li>
				</ul>
			</nav>
		</div>
	</section>

	<!--- First section --->
	<section class="section1">
        <div class="search-result">
        <?php
            if (isset($_POST['submit-search'])) {
                $search = mysqli_real_escape_string($conn, $_POST['search']);
                $sql = "SELECT personaldata.p_name, c_course, r_title, r_releaseDate FROM borrowerrecords INNER JOIN personaldata ON borrowerrecords.p_ID = personaldata.p_ID INNER JOIN coursedata ON personaldata.c_ID = coursedata.c_ID INNER JOIN resourcedata ON resourcedata.r_ID = borrowerrecords.r_ID WHERE personaldata.p_name LIKE '%$search%'";
                
                $result = mysqli_query($conn, $sql);
                $queryResult = mysqli_num_rows($result);
                echo "There are " .$queryResult. " result(s)! <br><br>"; 

                if ($queryResult > 0) {
                    echo "<table border=1><tr>
                    <th>Personal ID</th>
                    <th>Name</th>
                    <th>Book</th>
                    <th>Date of Release</th>
                    </tr>";
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr><td>" . 
                        $row['p_name']. "</td><td>" . 
                        $row['c_course']. "</td><td>" . 
                        $row['r_title']. "</td><td>" . 
                        $row['r_releaseDate']. "</td></tr>";
                    }
                    echo "</table>";
                }else {
                    echo "There are no results :/";
                }
            }
            echo "<h2>fuck ye</h2>"
        ?>
        </div>
	</section>
    <section class="footer">
        <div class="footer-logo">
			<img src="img/sec1logo.png">
		</div>
		<div class="footer-about">
			<p>© 2022 HMM School Library, All Rights Reserved</p>
		</div>
    </section>
</body>
</html>

