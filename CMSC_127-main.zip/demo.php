<?php
	include 'connect.php'
?>
<html lang=en>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> HMMbois - School Library </title> 
	<link  rel="stylesheet" type="text/css" href="style.css" />

	<!-- Usage of Online Resources -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

	<!---- Header section ---->
	<section class="header">
		<div class="navbar">
				<div class = "logo">
					<img src="img/logo.png" width="125px">
				</div>
			<nav>
				<ul>
					<li><a href="#header">Home</a></li>
					<li><a href="#header">Search</a></li>
				</ul>
			</nav>
		</div>
	</section>

	<!--- First section --->
	<section class="section1">
		<div class="sec1container">
			<div class="row">
				<div class="col-2">
				<h1>nakatikim ka na ba ng 2 pesos na takoyaki? </h1>
				</div>
				<div class="col-2">
					<img src="img/sec1logo.png" class="sec1logo">
				</div>
				<div class="searchbtn">
					<form action = "search.php" method ="POST" >
						<input type="text" name = "search" placeholder="Do you want to find something?" class="searchbar">
						<button type ="submit" name ="submit-search" class="submitbtn"><i class="fa fa-search"></i></button>
					</form>
				</div>
			</div>
		</div>
	</section>

		<!-- search function-->
		<!-- Nothing special just codes to display a table [can be removed]-->
		<div class="table">
				<table border="1">
					<tr>
						<th>Personal ID</th>
						<th>Name</th>
						<th>Course Number</th>
					</tr>
					
					<?php

						$sql1 = "SELECT * from personaldata";
						$result = $conn->query($sql1);

						if ($result->num_rows > 0) {
							// output data of each row
							while($row = $result->fetch_assoc()) {
							echo "<tr><td>" . 
							$row["p_ID"]. "</td><td>" . 
							$row["p_name"]. "</td><td>" . 
							$row["c_ID"]. "</td></tr>";

							}
							echo "</table>";
						} else {
							echo "0 results";
						}
						$conn->close();
					?>
		</div>
		<section class="footer">
			<div class="footer-logo">
				<img src="img/sec1logo.png">
			</div>
			<div class="footer-about">
				<p>© 2022 HMM School Library, All Rights Reserved</p>
			</div>
    </section>
	</body>
</html>

